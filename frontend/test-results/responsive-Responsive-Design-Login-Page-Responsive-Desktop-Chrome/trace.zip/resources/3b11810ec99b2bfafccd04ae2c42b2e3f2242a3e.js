(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__28bc9c2a._.css",
  "static/chunks/_4c8e88f2._.js"
],
    source: "dynamic"
});
